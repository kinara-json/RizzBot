module.exports = {
  "1": `💠 Putri Pukes dan Danau Laut Tawar
Di dataran tanah Gayo, hiduplah seorang putri raja bernama Putri Pukes. Sang Putri menyukai seorang pangeran dari kerajaan lain. Semula, kedua orang tuanya tidak merestui, karena negeri tempat tinggal pangeran itu jauh. Namun, karena kegigihan Putri Pukes dan Sang Pangeran, orangtua sang Putri pun merestui dan menikahkan mereka.

Setelah menikah, tibalah saatnya Putri Pukes harus menyusul suaminya. la pun pamit kepada orangtuanya untuk pergi ke kerajaan suaminya. Orangtua Putri Pukes sangat bersedih, tetapi mereka harus melepas anaknya itu pergi.

"Pergilah, Nak, bersama para pengawal. Namun, satu hal yang harus kau jaga, begitu melangkahkan kaki keluar dari kerajaan ini, sekali pun janganlah menoleh lagi ke belakang," pesan orangtuanya.

Putri Pukes pun berangkat bersama para pengawalnya. Di tengah jalan. ia selalu teringat akan orang tuanya dan sangat merindukan mereka. Karena ia terlalu bersedih, tanpa sengaja ia menoleh ke belakang.

Tiba-tiba, datanglah petir menyambar dan hujan yang sangat lebat. Putri Pukes dan rombongannya berteduh di dalam sebuah gua. Di dalam gua, Putri Pukes berdiri di sudut gua untuk menghangatkan tubuhnya yang kedinginan. Perlahan, sang Putri merasa tubuhnya mengeras. Putri Pukes sangat terkejut dan menangis.

Ternyata tubuhnya menjadi batu la menyesal karena tidak mengindahkan pesan orangtuanya. Seharusnya, la tidak menoleh ke belakang selama perjalanan. Setelah merasa cukup lama beristirahat dan hujan mulai reda, mereka berniat melanjutkan perjalanan. Para pengawal pun memanggil Sang Putri.

"Tuan Putri! Hujan sudah reda, mari kita melanjutkan perjalanan!" panggil para pengawal. Berkali-kali mereka memanggil, tetapi tetap tidak terdengar jawaban.

Para pengawal pun menghampiri tempat Putri Pukes berdiri. Mereka terus memanggil, tetapi sang Putri diam saja. Saat melihat dengan jelas, para pengawal sangat terkejut karena tubuh Putri Pukes telah mengeras dan menjadi batu. Sampai sekarang, batu Putri Pukes masih bisa dilihat.

Bentuknya membesar di bagian bawah, tetapi bentuk sanggul dan kepala Sang Putri masih bisa dikenall. Menurut kepercayaan penduduk, batu tersebut membesar di bawah karena Putri Pukes terus menangis yang menyebabkan air matanya menumpuk di bawah.

Sementara itu, karena hujan yang sangat lebat, terbentuklah danau di kawasan itu. Penduduk sekitar menyebut danau tersebut dengan nama Danau Laut Tawar.

Pesan moral dari cerita di atas adalah, patuhilah pesan orang tua kita, karena itu semua pasti demi kebaikan kita.
`,

  "2": `💠 Si Parkit Raja Parakeet
Konon, di tengah hutan belantara Aceh, hiduplah sekawanan burung parakeet yang hidup damai, tentram, dan makmur. Kawanan burung tersebut dipimpin oleh seorang raja parakeet yang bernama si Parkit.

Suatu hari datanglah seorang pemburu yang berniat menangkap mereka dengan cara memasang perekat. Si Parkit mengetahui niat jahat pemburu dan memberitahukan pada seluruh kawanan burung untuk berhati-hati.

Saat burung-burung itu keluar dari sarangnya untuk mencari makan, mereka tarekat pada perekat si Pemburu. Mereka berusaha melepaskan diri tetapi sia-sia. Melihat kejadian itu, si Parkit menenangkan rakyatnya dan memberi tahu untuk berpura-pura mati saat pemburu melepaskan mereka dari perekatnya, agar si Pemburu itu nantinya tidak jadi mengambil mereka.

Ternyata cara itu dapat mengelabui si Pemburu dan saat lengah, kawanan burung tersebut melarikan diri. Si Pemburu pun kaget dan menyadari bahwa ia telah ditipu. Malangnya, si Parkit justru masih terjebak. Pemburu segera menghampirinya dan mengancam akan membunuhnya. Si Parkit yang ketakutan pun membujuk si Pemburu agar tidak membunuhnya dan berjanji akan bernyanyi setiap hari untuk menghibur pemburu.

Sejak saat itu, setiap hari si Parkit selalu bernyanyi. Banyak orang yang memuji kemerduan si Parkit, salah satunya Raja Aceh. Akhirnya, dengan menyerahkan sejumlah uang kepada pemburu, si Parkit menjadi milik raja. la dibawa ke istana, dimasukkan ke dalam sangkar emas, dan diberikan makanan enak setiap harinya.

Meskipun serba enak, si Parkit tetap ingin kembali ke hutan, agar ia bisa ter- bang bebas bersama rakyatnya. Si Parkit pun memikirkan cara untuk bisa keluar dari sangkar dan memutuskan untuk berpura-pura mati.

Suatu hari, petugas istana melaporkan kematian si Parkit pada raja. Sang raja pun sedih mendengar berita kematian itu. Namun, ketika hendak dikebumikan, si Parkit dengan cepat terbang setinggi-tingginya. Akhirnya si Parkit yang cerdik itu bisa kembali ke hutan. Kedatangan si Parkit pun disambut dengan meriah oleh rakyatnya.

Cerita ini dikutip dari buku Rangkuman 100 Cerita Rakyat Indonesia: Dari Sabang Sampai Merauke karya Irwan dan Shenia.
`,

  "3": `💠 Malin Kundang
Di pesisir pantai wilayah Sumatera hiduplah seorang anak laki-laki yang bernama Malin Kundang bersama ayah ibunya. Suatu hari ayahnya pergi mengadu nasib ke negeri seberang dengan mengarungi lautan yang luas. Hampir setahun ayahnya tidak pernah kembali dan dikabarkan telah meninggal.

Sejak saat itu, ibunya yang mencari nafkah untuk mereka berdua. Malin anak yang cerdas walau kadang nakal. la suka mengejar ayam hingga suatu kali terjatuh dan meninggalkan bekas luka di lengannya.

Saat dewasa, Malin Kundang merasa kasihan dengan ibunya yang sudah tua tetapi tetap bekerja, la pun menyampaikan niatnya untuk mencari nafkah di negeri seberang. Walaupun awalnya ibunya tidak setuju, tapi akhirnya ia tetap mengizinkannya untuk pergi.

Di tengah perjalanan, tiba-tiba kapal yang dinaiki Malin Kundang diserang oleh bajak laut. Malin Kundang sangat beruntung dirinya selamat dan tidak dibunuh karena Malin bisa bersembunyi di sebuah ruang kecil yang tertutup oleh kayu.

Malin Kundang terkatung-katung di tengah laut, hingga akhirnya kapal yang ditumpanginya terdampar di sebuah pantai. Dengan sisa tenaga yang ada, Malin Kundang berjalan menuju ke desa yang terdekat dari pantai. Selanjutnya, Malin menetap di desa itu dan bekerja dengan gigih dan ulet.

Malin pun menjadi kaya raya dan ia pun telah mempersunting seorang gadis. Berita Malin Kundang yang telah menjadi kaya raya dan telah menikah sampai juga kepada ibunya. Ibu Malin Kundang merasa bersyukur anaknya telah berhasil.

Suatu hari Malin dan istrinya melakukan pelayaran ke kampungnya dengan kapal yang besar dan indah disertai anak buah kapal serta pengawalnya. Saat Malin turun dari kapal, ibunya berdiri cukup dekat dan meyakini bahwa itu anaknya karena ia melihat bekas luka di lengannya.

Ia pun segera memeluk Malin, tetapi dengan kasarnya Malin melepaskan pelukan. Bahkan, mendorongnya, menghinanya, serta tidak mengakui bahwa wanita itu ibunya. Ibu Malin sangat sedih dan marah.

Karena itu ia segera menengadahkan tangan, "Oh Tuhan, kalau benar ia anakku, aku sumpahi dia menjadi sebuah batu". Tidak berapa lama kemudian angin bergemuruh kencang dan badai dahsyat. Tubuh Malin Kundang pun perlahan kaku dan menjadi sebuah batu karang.
`,

  "4": `💠 Asal Usul Danau Lau Kawar
Lau Kawar adalah sebuah danau yang terletak di Desa Kuta Gugung, Kecamatan Simpang Empat, Kabupaten Karo, Sumatera Utara. Danau ini dikelilingi oleh bunga-bunga anggrek yang indah dan pemandangan alam yang memesona.

Dahulu kala, Desa Kawar merupakan desa yang subur. Suatu ketika, hasil panen penduduk berlimpah ruah. Para penduduk pun mengadakan acara adat sebagai bentuk syukur kepada Tuhan Yang Maha Esa.

Penduduk desa bersukacita menghadiri acara itu. Semua penduduk hadir, kecuali seorang nenek yang sedang terbaring sakit di rumahnya. Semua anggota keluarga nenek itu pergi ke pesta dan meninggalkan sang nenek seorang diri.

Suara yang ramai membangunkan si nenek. Perutnya terasa lapar. Dengan susah payah ia turun dari tempat tidur dan beringsut ke dapur untuk mencari makanan. Sayangnya, tidak ada sedikitpun makanan di dapur.

Nenek itu kembali ke tempat tidur. la sangat sedih, karena anak dan menantunya tidak ingat kepadanya. Padahal, di tempat pesta, makanan berlebih. Air matanya bercucuran.

Ketika pesta makan-makan usai, barulah anaknya ingat bahwa ibunya belum makan. Ia menyuruh istrinya mengirimkan makanan untuk ibu mereka di rumah. Istrinya segera membungkus makanan dan menyuruh anaknya mengantarkan makanan itu.

Di perjalanan ke rumah nenek, si anak merasa lapar. la pun menyantap makanan untuk neneknya, lalu membungkusnya kembali. Setelah mengantar makanan, anak itu kembali lagi ke tempat pesta.

Si nenek sangat senang ketika cucunya datang membawa makanan. Namun, ia terkejut saat membuka bungkusan tersebut. Isinya hanyalah sisa-sisa makanan yang menjijikkan.

Si nenek sangat sedih, air matanya berlinang. Dalam kesedihannya, la berdoa kepada Tuhan.

"Ya Tuhan, betapa durhakanya mereka kepadaku. Berikanlah pelajaran yang setimpal kepada mereka!" doanya. Tak lama kemudian, terjadilah gempa bumi yang dahsyat. Petir menyambar dan guntur menggelegar. Hujan turun begitu derasnya.

Penduduk yang menyelenggarakan pesta rakyat berlari dengan panik sambil menjerit ketakutan. Namun, hujan semakin deras. Dalam sekejap, Desa Kawar pun tenggelam. Tak ada seorang pun selamat. Desa yang subur dan makmur itu telah berubah menjadi sebuah danau besar yang digenangi air. Danau tersebut disebut dengan Lau Kawar.

Pesan moral dari cerita ini adalah, dalam keadaan apa pun kita harus selalu berbakti kepada orang tua, jangan durhaka apalagi sampai mengabaikannya.
`,

  "5": `💠 Batu Menangis
Alkisah, di sebuah desa terpencil hiduplah seorang janda tua dengan seorang putrinya yang cantik jelita bernama Darmi. Mereka tinggal di sebuah gubuk yang terletak di ujung desa.

Darmi memang cantik, parasnya indah menawan. Namun, tingkah lakunya sangatlah tidak cantik dan sifatnya sangatlah tidak menarik.

Setiap hari Darmi selalu bersolek di kamarnya. Ia tidak pernah mau membantu ibunya sedikit pun membereskan isi rumah. Kamarnya selalu berantakan. Darmi tidak peduli akan hal itu, ia hanya peduli pada wajahnya yang cantik jelita tiada terkira haruslah selalu tampil sempurna.

Ibunya Darmi yang sudah tua, setiap hari selalu bekerja keras demi mendapatkan uang. Apa pun jenis pekerjaannya, selama itu halal, akan ia kerjakan. Semua itu ia lakukan hanya untuk memenuhi kebutuhan hidupnya dan kebutuhan Darmi, anak semata wayangnya.

Ibunya Darmi juga kerap diperlakukan seperti pembantu. Setiap ditanya siapa yang berjalan di belakangmu, ia selalu menjawab bahwa ibunya adalah budaknya.

Mendengar hal itu terus menerus, Ibu Darmi merasa sakit hati hingga berdo'a. Secara perlahan Darmi berubah menjadi batu. Ia terus menangis dan memohon kepada ibunya. Namun, semua sudah terlambat. Kini tubuhnya berubah menjadi batu yang terus mengeluarkan air mata.

Cerita ini dikutip dari buku Batu Menangis karya Noor H.Dee, yang berisi pesan moral bahwa kita harus senantiasa berbakti kepada orang tua.
`,

  "6": `💠 Bawang Merah dan Bawang Putih
Dahulu kala, hiduplah Bawang Putih dan saudara tirinya, Bawang Merah. Ibu Bawang Putih meninggal ketika ia masih bayi. Kemudian ayahnya menikah lagi dengan wanita lain dan memiliki anak bernama Bawang Merah.

Tak berselang lama, ayahnya pun meninggal. Setelah itu, kehidupan Bawang Putih amat menyedihkan. Kesehariannya, Bawang Putih selalu diminta untuk mengerjakan seluruh pekerjaan rumah termasuk mencuci baju.

Suatu hari ketika sedang mencuci, baju ibu tiri Bawang Putih hanyut. Bawang Putih pun bingung sampai akhirnya bertemu dengan seorang nenek yang mengatakan kalau ia menyimpan baju yang hanyut itu dan akan mengembalikannya dengan satu syarat. Bawang Putih harus membantu mengerjakan pekerjaan rumah. Bawang Putih pun menuruti.

Setelah selesai, nenek itu mengembalikan baju ibu tirinya. Nenek itu juga memberinya hadiah. Bawang Putih harus memilih salah satu labu untuk dibawa pulang, ada labu besar dan labu kecil. Bawang Putih memilih yang kecil. Sesampainya di rumah alangkah terkejutnya ia beserta ibu dan saudara tirinya, ternyata labu itu berisi banyak perhiasan.

Keesokan harinya, Bawang Merah melakukan hal yang sama seperti Bawang Putih. Ia pura-pura menghanyutkan pakaiannya. Kemudian, memilih labu yang besar. Ketika dibuka labu itu malah berisi ular.

Bawang Merah dan ibunya pun merasa itu adalah bentuk teguran dari Tuhan untuk mereka karena sudah memperlakukan Bawang Putih layaknya seorang pembantu. Mereka menyadari semua kesalahannya selama ini pada Bawang Putih dan meminta maaf.

Pesan moralnya adalah, kita tidak boleh berperilaku buruk terhadap orang lain dan memiliki sifat serakah.
`,

  "7": `💠 Si Tikus dan Si Singa
Suatu saat ada Tikus yang menjahili Singa dikala sedang menikmati tidur siang, sontak membuat Singa tersebut marah dan ingin memakan sang Tikus karena merasa terganggu.

Sambil meringis ketakutan, Tikus pun memohon kepada Singa untuk melepaskannya dan memaafkan kejahilan yang ia perbuat. Merasa kasihan, Singa melepaskan Tikus. Tikus merasa senang, ia berterima kasih dan berjanji untuk membalas semua kebaikan Singa padanya.

Lalu pada suatu hari, Tikus mendengar suara Singa yang mengaung keras. Sang Singa ternyata terperangkap di sebuah jaring yang sengaja dipasang oleh pemburu. Singa memohon bantuan Tikus untuk melepaskan jaring tersebut. Dengan sigap, Tikus membantu Singa keluar dari jaring tersebut dengan menggerogoti jaring sampai terputus. Keduanya pun segera kabur dan menyelamatkan diri.

Kisah persahabatan Tikus dan Singa ini menjadi inspirasi bagi anak untuk selalu berbuat kebaikan dan mengingat semua kebaikan yang kita terima.
`,

  "8": `💠 Hang Tuah
Pada masa lalu, dikenal seorang ksatria bernama Hang Tuah. Saat berumur sepuluh tahun, Hang Tuah pergi berlayar ke Laut Cina Selatan disertai empat sahabatnya, yaitu Hang Jebat, Hang Kasturi, Hang Lekir, dan Hang Lekiu.

Dalam perjalanan, mereka berkali-kali diganggu oleh gerombolan bajak laut, tetapi mereka selalu berhasil mengalahkan gerombolan itu. Kabar tersebut terdengar sampai ke telinga Bendahara Paduka Raja Bintan. la pun mengangkat mereka sebagai anak angkatnya.

Suatu hari di istana Majapahit terjadi sebuah kegaduhan. Taming Sari, prajurit Majapahit yang sudah tua tapi amat tangguh, tiba-tiba mengamuk. Mengetahui keadaan itu, Hang Tuah kemudian menghadang Taming Sari dan berhasil mengalahkannya. Hang Tuah kemudian diberi gelar Laksamana dan dihadiahi keris Taming Sari.

Hang Tuah menjadi laksamana yang amat setia, amat disayang, serta dipercaya raja. Hal itu menimbulkan rasa iri pada Patih Kerma Wijaya, sehingga ia pun menyebar fitnah. Baginda Raja pun marah dan mengusir Hang Tuah. Ia pun segera meninggalkan Melaka dan pergi ke Indrapura. Suatu waktu, di Indrapura ia kedatangan tamu dari Melaka yang memintanya kembali ke Melaka, dan mendapat tugas menjadi Laksamana Melaka lagi.

Suatu hari, Hang Tuah melakukan pelayaran ke negeri Cina. Di pelabuhan Cina, rombongannya berselisih paham dengan orang-orang Portugis. Dalam perjalanan pulang kembali ke Melaka, mereka diserang oleh Portugis, tetapi Hang Tuah mampu mengatasi serangan mereka dan selamat.

Sementara itu, Gubernur Portugis di Manila sangat marah mendengar laporan kekalahan dan melakukan penyerangan ke Selat Melaka sebagai balas dendam. Pada saat itu Baginda Raja memerintahkan Tuan Bendahara untuk meminta bantuan Hang Tuah.

Meski sakit, Hang Tuah tetap memimpin pasukan. Namun, sebuah peluru mesiu Portugis menghantam Hang Tuah. Ia terlempar sejauh 7 meter dan terjatuh ke laut. Beruntung, Hang Tuah berhasil diselamatkan.

Akhirnya, peperangan berakhir tanpa pemenang dan yang kalah. Setelah sembuh, Hang Tuah tidak lagi menjabat sebagai Laksamana Melaka karena sudah semakin tua. Ia menjalani hidupnya dengan menyepi di puncak bukit Jugra di Melaka.
`,

  "9": `💠 Anak Beruang dan Lebah
Suatu hari, seekor beruang tengah menjelajahi hutan untuk mencari buah-buahan. Di tengah pencarian, ia menemukan pohon tumbang di mana terdapat sarang tempat lebah menyimpan madu.

Beruang itu mulai mengendus-endus dengan hati-hati di sekitar pohon tumbang tersebut untuk mencari tahu apakah lebah-lebah sedang berada dalam sarang tersebut. Tepat pada saat itu, sekumpulan kecil lebah terbang pulang dengan membawa banyak madu.

Lebah-lebah yang pulang tersebut, tahu akan maksud sang Beruang dan mulai terbang mendekati sang Beruang, menyengatnya dengan tajam lalu lari bersembunyi ke dalam lubang batang pohon.

Seketika Beruang tersebut menjadi sangat marah, loncat ke atas batang yang tumbang tersebut dan dengan cakarnya menghancurkan sarang lebah. Tetapi hal ini malah membuat seluruh kawanan lebah yang berada dalam sarang, keluar dan menyerang sang Beruang.

Beruang yang malang itu akhirnya lari terbirit-birit dan hanya dapat menyelamatkan dirinya dengan cara menyelam ke dalam air sungai.

Dari cerita ini, dapat ditarik pesan moral bahwa jangan menjadi orang yang serakah. Karena untuk mendapat kesuksesan, diperlukan kerja keras dan kesabaran.
`,

  "10": `💠 Kelingking Sakti
Pada zaman dahulu kala, di sebuah desa di Kepulauan Riau, hiduplah sepasang suami-istri yang sangat miskin. Mereka mempunyai tiga orang anak laki-laki bernama Salimbo, Ngah, dan Kelingking. Saat Kelingking berusia 5 bulan, ibunya meninggal dunia. Sejak saat itu mereka tinggal berempat.

Waktu terus berlalu. Kelingking sudah dewasa. la pun berniat merantau, dan menyampaikan niat tersebut pada ayahnya. Meskipun berat hati, sang ayah mengizinkannya. Esoknya, dengan berbekal tujuh buah ketupat, berangkatlah Kelingking merantau.

Selama dalam perjalanan, ia makan buah dan daun-daunan yang ditemuinya sehingga bekal ketupatnya masih utuh. Suatu siang, sampailah Kelingking di hutan lebat. Kemudian ia tertidur di bawah pohon rindang.

Dalam tidurnya, ia mendengar suara yang mengatakan, jika ia ingin menikah dengan seorang putri, ia harus mengikatkan ketupatnya dengan akar tuba dan memasukkannya ke dalam sungai yang mengalir di hutan ini.

Apabila air sungai itu sudah berbuih, berarti ikan besar di dalamnya sudah mati. Lalu, ambil ikannya. Saat terbangun, Kelingking pun melaksanakan semua perintah dalam mimpinya. Sampai akhirnya ia mendapatkan ikan yang kemudian ia bakar dan makan sendiri hingga hanya kepala ikan yang tersisa.

Setelah itu Kelingking bingung karena tidak ada tanda-tanda kedatangan seorang putri. Akhirnya, dengan kesal, ia menendang kepala ikan itu hingga melambung tinggi dan tidak memperdulikannya lagi.

Ia pun melanjutkan pengembaraannya hingga sampai di sebuah kampung. Ternyata, di kampung itu, seorang raja sedang mengadakan sayembara untuk memindahkan kepala ikan yang mengganggu pemandangan istana. Jika laki-laki, akan dinikahkan dengan putrinya, dan jika perempuan akan diangkat sebagai anaknya.

Melihat kepala ikan itu, Kelingking merasa mengenalnya. Ia pun mendaftar- kan diri. Tidak seorang pun yang mampu menggerakkannya hingga tibalah giliran Kelingking. Semua orang mencemooh badannya yang kecil.

Namun, dengan mudahnya ia mengangkat kepala ikan itu dan menguburnya di belakang istana. la pun berhak menikah dengan putri raja. Seluruh istana dan penduduk negeri berbahagia atas pernikahan tersebut. Kelingking pun tak lupa menjemput ayah dan kedua abangnya untuk tinggal bersama di istana.
`
}